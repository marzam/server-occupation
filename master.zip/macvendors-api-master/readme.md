## Macvendors.co API in PHP

### Overview
Lookup any vendor using mac address,or search by company name or address to get it's mac prefix.

This class is the implementation of macvendors.co API.

This class support alot of methods, please use the attached example.php file within this repository.


## Support
For support please contact us via http://macvendors.co